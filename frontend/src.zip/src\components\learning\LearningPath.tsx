import { useEffect, useRef } from 'react';
import type { LearningPathData } from '../../types/learningPath';
import EmptyState from '../common/EmptyState';
import { renderMermaid } from '../../utils/mermaid';

interface Props {
  path: LearningPathData | null;
  onNodeClick?: (stageIndex: number) => void;
}

function buildMermaidFlowchart(path: LearningPathData): string {
  let chart = 'graph TD\n';
  chart += '  classDef completed fill:#d1fae5,stroke:#10b981,stroke-width:2px\n';
  chart += '  classDef inProgress fill:#dbeafe,stroke:#3b82f6,stroke-width:2px\n';
  chart += '  classDef pending fill:#f3f4f6,stroke:#d1d5db,stroke-width:2px\n';
  chart += '  classDef locked fill:#f9fafb,stroke:#e5e7eb,stroke-width:1px,stroke-dasharray:5 5\n';

  path.stages.forEach((stage, i) => {
    const nodeId = `S${stage.stage}`;
    const label = `${stage.topic}\n${stage.duration}`;
    chart += `  ${nodeId}["${label}"]\n`;
    chart += `  class ${nodeId} ${stage.status === 'completed' ? 'completed' : stage.status === 'in_progress' ? 'inProgress' : stage.status === 'pending' ? 'pending' : 'locked'}\n`;
    if (i > 0) {
      chart += `  S${path.stages[i - 1].stage} --> ${nodeId}\n`;
    }
  });

  return chart;
}

export default function LearningPath({ path, onNodeClick }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current && path) {
      const code = buildMermaidFlowchart(path);
      renderMermaid(containerRef.current, code).then(() => {
        // Ϊ�ڵ����ӵ���¼�����ѡ��չ��
      });
    }
  }, [path]);

  if (!path) {
    return (
      <EmptyState
        title="����ѧϰ·��"
        description="���ѧϰ��Ϻ�ϵͳ��Ϊ��滮���Ի�ѧϰ·��"
      />
    );
  }

  return (
    <div className="p-4 overflow-auto">
      <div ref={containerRef} className="min-w-[600px] flex justify-center" />
    </div>
  );
}