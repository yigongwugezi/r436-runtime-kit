import client from './client';
import type { QuizResult } from '../types/resource';

export interface FeedbackResponse {
  updated_profile: Record<string, unknown>;
  feedback: string;
  error_analysis: string[];
}

export async function submitQuizResults(quizResults: QuizResult[]): Promise<FeedbackResponse> {
  const { data } = await client.post<FeedbackResponse>('/feedback', { quiz_results: quizResults });
  return data;
}