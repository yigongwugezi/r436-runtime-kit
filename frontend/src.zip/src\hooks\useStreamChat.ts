import { useCallback } from 'react';
import { useChatStore } from '../store/chatStore';
import { sendStreamMessage } from '../api/chat';
import { generateId } from '../utils/format';
import type { Message, StreamStage } from '../types/chat';

export function useStreamChat() {
  const { messages, isStreaming, addMessage, updateLastMessage, setStreaming, setStage, setProgress, setError } =
    useChatStore();

  const send = useCallback(
    async (text: string) => {
      if (!text.trim() || isStreaming) return;

      const userMessage: Message = {
        id: generateId(),
        role: 'user',
        content: text,
        timestamp: Date.now(),
      };
      addMessage(userMessage);

      const assistantMessage: Message = {
        id: generateId(),
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
      };
      addMessage(assistantMessage);

      setStreaming(true);
      setError(null);

      await sendStreamMessage(
        text,
        (chunk) => updateLastMessage(chunk),
        (stage, progress) => {
          setStage(stage as StreamStage);
          setProgress(progress);
        },
        () => {
          setStreaming(false);
          setStage(null);
          setProgress(0);
        },
        (err) => {
          setError(err.message);
          setStreaming(false);
        }
      );
    },
    [isStreaming, addMessage, updateLastMessage, setStreaming, setStage, setProgress, setError]
  );

  return { messages, isStreaming, send };
}