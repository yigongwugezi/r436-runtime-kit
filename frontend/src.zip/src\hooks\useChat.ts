import { useCallback } from 'react';
import { useChatStore } from '../store/chatStore';
import { useProfileStore } from '../store/profileStore';
import { sendMessage } from '../api/chat';
import { generateId } from '../utils/format';
import type { Message } from '../types/chat';

export function useChat() {
  const { messages, isStreaming, addMessage, setStreaming, setError, setSessionId } = useChatStore();
  const { setProfile } = useProfileStore();

  const send = useCallback(
    async (text: string) => {
      if (!text.trim() || isStreaming) return;

      const userMessage: Message = {
        id: generateId(),
        role: 'user',
        content: text,
        timestamp: Date.now(),
      };

      addMessage(userMessage);
      setStreaming(true);
      setError(null);

      try {
        const response = await sendMessage(text);
        setSessionId(response.profile.session_id);
        setProfile(response.profile);

        const assistantMessage: Message = {
          id: generateId(),
          role: 'assistant',
          content: response.reply,
          timestamp: Date.now(),
        };

        addMessage(assistantMessage);

        if (response.follow_up_questions?.length > 0) {
          const followUp: Message = {
            id: generateId(),
            role: 'system',
            content: `? ����Իظ���${response.follow_up_questions.join(' �� ')}`,
            timestamp: Date.now(),
          };
          addMessage(followUp);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : '����ʧ��');
        addMessage({
          id: generateId(),
          role: 'system',
          content: '��Ǹ����Ϣ����ʧ�ܣ������ԡ�',
          timestamp: Date.now(),
        });
      } finally {
        setStreaming(false);
      }
    },
    [isStreaming, addMessage, setStreaming, setError, setSessionId, setProfile]
  );

  return { messages, isStreaming, send };
}