import { useEffect, useRef } from 'react';
import * as echarts from 'echarts';
import type { StudentProfile } from '../../types/profile';

interface Props {
  profile: StudentProfile;
}

const dimensionOrder = [
  'knowledge_base',
  'programming_ability',
  'cognitive_style',
  'learning_pace',
  'interest_direction',
];

const dimensionLabels: Record<string, string> = {
  knowledge_base: '֪ʶ����',
  programming_ability: '�������',
  cognitive_style: '��֪���',
  learning_pace: 'ѧϰ����',
  interest_direction: '��Ȥ����',
};

export default function DimensionRadar({ profile }: Props) {
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    const chart = echarts.init(chartRef.current);

    const indicators = dimensionOrder.map((key) => ({
      name: dimensionLabels[key],
      max: 1,
    }));

    const data = dimensionOrder.map((key) => {
      const dim = profile.dimensions[key as keyof typeof profile.dimensions];
      if (!dim) return 0;
      if (typeof dim.value === 'object' && dim.value !== null) {
        const vals = Object.values(dim.value as Record<string, number>);
        return vals.length > 0 ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      }
      return dim.confidence;
    });

    chart.setOption({
      radar: {
        indicators,
        center: ['50%', '50%'],
        radius: '70%',
        axisName: { fontSize: 11, color: '#6b7280' },
      },
      series: [
        {
          type: 'radar',
          data: [{ value: data, name: '��ǰˮƽ' }],
          areaStyle: { color: 'rgba(59, 130, 246, 0.15)' },
          lineStyle: { color: '#3b82f6', width: 2 },
          itemStyle: { color: '#3b82f6' },
          symbol: 'circle',
          symbolSize: 5,
        },
      ],
    });

    return () => chart.dispose();
  }, [profile]);

  return <div ref={chartRef} className="w-full h-64" />;
}