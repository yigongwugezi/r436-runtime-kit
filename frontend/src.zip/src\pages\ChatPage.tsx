import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import ChatPanel from '../components/chat/ChatPanel';
import ProfileCard from '../components/profile/ProfileCard';
import DimensionRadar from '../components/profile/DimensionRadar';
import ResourceCard from '../components/resources/ResourceCard';
import { useChatStore } from '../store/chatStore';
import { useProfileStore } from '../store/profileStore';
import { RESOURCE_TYPE_LABELS } from '../utils/constants';

export default function ChatPage() {
  const location = useLocation();
  const { messages } = useChatStore();
  const { profile } = useProfileStore();
  const initialMessage = (location.state as { initialMessage?: string })?.initialMessage;

  useEffect(() => {
    if (initialMessage) {
      // �Զ����ͳ�ʼ��Ϣ����Ҫ�� ChatPanel ���غ�ͨ���¼�������
      const timer = setTimeout(() => {
        const event = new CustomEvent('auto-send', { detail: initialMessage });
        window.dispatchEvent(event);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [initialMessage]);

  return (
    <div className="flex h-[calc(100vh-4rem)] md:h-[calc(100vh-3.5rem)]">
      {/* ���Ի��� */}
      <div className="flex-1 min-w-0 border-r border-gray-200 flex flex-col">
        <ChatPanel />
      </div>

      {/* �м�״̬��壨����˿ɼ��� */}
      <div className="hidden lg:flex flex-col w-72 border-r border-gray-200 p-4 gap-4 overflow-y-auto">
        <ProfileCard profile={profile} />
        {profile && <DimensionRadar profile={profile} />}
      </div>

      {/* �Ҳ���Դ��壨����˿ɼ��� */}
      <div className="hidden xl:flex flex-col w-80 p-4 overflow-y-auto gap-3">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">? ѧϰ��Դ</h3>
        {messages.length > 0 ? (
          <p className="text-sm text-gray-400">�ڶԻ������ɵ���Դ����ʾ������</p>
        ) : (
          <p className="text-sm text-gray-400">���͵�һ����Ϣ��ʼѧϰ</p>
        )}
      </div>
    </div>
  );
}