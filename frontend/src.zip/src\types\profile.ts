// ===== ѧ���������� =====

export type DimensionSource = 'user_input' | 'inferred' | 'diagnosis';

export interface DimensionValue<T = unknown> {
  value: T;
  confidence: number;
  source: DimensionSource;
  last_updated: string;
}

export interface KnowledgeBase {
  [key: string]: number;
}

export interface StudentProfile {
  session_id: string;
  dimensions: {
    major: DimensionValue<string>;
    grade: DimensionValue<string>;
    knowledge_base: DimensionValue<KnowledgeBase>;
    learning_goal: DimensionValue<string>;
    cognitive_style: DimensionValue<string>;
    weakness_patterns: DimensionValue<string[]>;
    programming_ability: DimensionValue<string>;
    learning_pace: DimensionValue<string>;
    interest_direction: DimensionValue<string>;
    available_time: DimensionValue<string>;
  };
}

export interface ProfileHistoryItem {
  timestamp: string;
  dimension: string;
  old_value: DimensionValue;
  new_value: DimensionValue;
}

export interface LearningStats {
  total_knowledge_points: number;
  mastered_count: number;
  total_resources: number;
  quiz_accuracy: number;
  study_days: number;
  total_study_hours: number;
}