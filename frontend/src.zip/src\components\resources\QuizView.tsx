import { useState } from 'react';
import { CheckCircle, XCircle, Lightbulb } from 'lucide-react';
import type { QuizQuestion, QuizResult } from '../../types/resource';

interface Props {
  questions: QuizQuestion[];
  onSubmit: (results: QuizResult[]) => void;
}

export default function QuizView({ questions, onSubmit }: Props) {
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [results, setResults] = useState<QuizResult[]>([]);

  const handleSelect = (questionIndex: number, answer: string) => {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [questionIndex]: answer }));
  };

  const handleSubmit = () => {
    const res: QuizResult[] = questions.map((q, i) => ({
      question_index: i,
      user_answer: answers[i] || '',
      correct: answers[i] === q.answer,
    }));
    setResults(res);
    setSubmitted(true);
    onSubmit(res);
  };

  return (
    <div className="space-y-6 p-4">
      {questions.map((q, qi) => (
        <div key={qi} className="bg-white border border-gray-200 rounded-xl p-4">
          <div className="flex items-start justify-between mb-3">
            <h4 className="font-medium text-gray-900">
              <span className="text-blue-600 mr-2">Q{qi + 1}.</span>
              {q.question}
            </h4>
            {submitted && results[qi] && (
              results[qi].correct
                ? <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                : <XCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
            )}
          </div>

          {q.options && (
            <div className="space-y-2">
              {q.options.map((opt, oi) => {
                const letter = String.fromCharCode(65 + oi);
                const isSelected = answers[qi] === letter;
                const isCorrect = q.answer === letter;

                let optionClass = 'border-gray-200 hover:border-blue-300';
                if (submitted && isSelected) {
                  optionClass = isCorrect
                    ? 'border-green-500 bg-green-50'
                    : 'border-red-500 bg-red-50';
                } else if (submitted && isCorrect) {
                  optionClass = 'border-green-500 bg-green-50';
                } else if (isSelected) {
                  optionClass = 'border-blue-500 bg-blue-50';
                }

                return (
                  <button
                    key={oi}
                    onClick={() => handleSelect(qi, letter)}
                    disabled={submitted}
                    className={`w-full text-left px-4 py-3 rounded-lg border transition-colors ${optionClass}`}
                  >
                    <span className="font-medium text-gray-600 mr-2">{letter}.</span>
                    <span className="text-gray-700">{opt}</span>
                  </button>
                );
              })}
            </div>
          )}

          {submitted && (
            <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-2">
                <Lightbulb className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-yellow-800">����</p>
                  <p className="text-sm text-yellow-700 mt-0.5">{q.solution}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}

      {!submitted && (
        <button
          onClick={handleSubmit}
          disabled={Object.keys(answers).length < questions.length}
          className="w-full py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          �ύ��
        </button>
      )}
    </div>
  );
}