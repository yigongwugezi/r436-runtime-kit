import client from './client';
import type { StudentProfile, LearningStats, ProfileHistoryItem } from '../types/profile';

export async function getProfile(sessionId: string): Promise<StudentProfile> {
  const { data } = await client.get<StudentProfile>(`/profile/${sessionId}`);
  return data;
}

export async function updateProfile(dimension: string, value: unknown): Promise<StudentProfile> {
  const sessionId = localStorage.getItem('eduagent_session_id');
  const { data } = await client.put<StudentProfile>(`/profile/${sessionId}`, {
    dimension,
    value,
  });
  return data;
}

export async function getLearningStats(sessionId: string): Promise<LearningStats> {
  const { data } = await client.get<LearningStats>(`/profile/${sessionId}/stats`);
  return data;
}

export async function getProfileHistory(sessionId: string): Promise<ProfileHistoryItem[]> {
  const { data } = await client.get<ProfileHistoryItem[]>(`/profile/${sessionId}/history`);
  return data;
}