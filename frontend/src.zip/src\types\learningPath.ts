// ===== ѧϰ·������ =====

export type StageStatus = 'completed' | 'in_progress' | 'pending' | 'locked';

export interface PathStage {
  stage: number;
  topic: string;
  description: string;
  duration: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  status: StageStatus;
  resources: string[];
  prerequisites: string[];
  knowledge_points: string[];
}

export interface LearningPathData {
  session_id: string;
  stages: PathStage[];
  current_stage: number;
  total_progress: number;
  created_at: string;
  updated_at: string;
}