import { QUICK_COMMANDS } from '../../utils/constants';

interface Props {
  onSelect: (message: string) => void;
}

export default function QuickCommands({ onSelect }: Props) {
  return (
    <div className="flex gap-2 flex-wrap">
      {QUICK_COMMANDS.map((cmd) => (
        <button
          key={cmd.label}
          onClick={() => onSelect(cmd.message)}
          className="px-3 py-1 text-xs bg-gray-100 text-gray-600 rounded-full hover:bg-blue-50 hover:text-blue-600 transition-colors"
        >
          {cmd.label}
        </button>
      ))}
    </div>
  );
}