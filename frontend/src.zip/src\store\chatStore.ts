import { create } from 'zustand';
import type { Message, StreamStage } from '../types/chat';

interface ChatState {
  sessionId: string;
  messages: Message[];
  isStreaming: boolean;
  currentStage: StreamStage | null;
  progress: number;
  error: string | null;

  setSessionId: (id: string) => void;
  addMessage: (message: Message) => void;
  updateLastMessage: (chunk: string) => void;
  setStreaming: (streaming: boolean) => void;
  setStage: (stage: StreamStage | null) => void;
  setProgress: (progress: number) => void;
  setError: (error: string | null) => void;
  clearMessages: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  sessionId: localStorage.getItem('eduagent_session_id') || '',
  messages: [],
  isStreaming: false,
  currentStage: null,
  progress: 0,
  error: null,

  setSessionId: (id) => {
    localStorage.setItem('eduagent_session_id', id);
    set({ sessionId: id });
  },

  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),

  updateLastMessage: (chunk) =>
    set((state) => {
      const messages = [...state.messages];
      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.role === 'assistant') {
        messages[messages.length - 1] = {
          ...lastMsg,
          content: lastMsg.content + chunk,
        };
      }
      return { messages };
    }),

  setStreaming: (streaming) => set({ isStreaming: streaming }),
  setStage: (stage) => set({ currentStage: stage }),
  setProgress: (progress) => set({ progress }),
  setError: (error) => set({ error }),
  clearMessages: () => set({ messages: [], error: null }),
}));