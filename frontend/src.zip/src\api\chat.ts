import client from './client';
import type { ChatRequest, ChatResponse } from '../types/chat';

export async function sendMessage(message: string): Promise<ChatResponse> {
  const { data } = await client.post<ChatResponse>('/dialogue', { message });
  return data;
}

export async function sendStreamMessage(
  message: string,
  onChunk: (text: string) => void,
  onStage: (stage: string, progress: number) => void,
  onComplete: () => void,
  onError: (error: Error) => void
): Promise<void> {
  try {
    const response = await fetch(`${client.defaults.baseURL}/dialogue/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) throw new Error('��ʽ����ʧ��');

    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const event = JSON.parse(line.slice(6));
            if (event.stage) {
              onStage(event.stage, event.progress || 0);
            }
            if (event.chunk) {
              onChunk(event.chunk);
            }
          } catch {
            // ��JSON������
          }
        }
      }
    }
    onComplete();
  } catch (error) {
    onError(error instanceof Error ? error : new Error('��ʽ����ʧ��'));
  }
}