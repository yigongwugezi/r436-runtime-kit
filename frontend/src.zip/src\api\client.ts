import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import { API_BASE_URL, SESSION_KEY } from '../utils/constants';

const client = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60000,
  headers: {
    'Content-Type': 'application/json',
  },
});

client.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const sessionId = localStorage.getItem(SESSION_KEY);
  if (sessionId && config.data && typeof config.data === 'object') {
    config.data.session_id = sessionId;
  }
  return config;
});

client.interceptors.response.use(
  (response) => response,
  (error: AxiosError<{ detail: string }>) => {
    const message = error.response?.data?.detail || error.message || '��������ʧ��';
    console.error(`[API Error] ${error.config?.url}: ${message}`);
    return Promise.reject(new Error(message));
  }
);

export default client;