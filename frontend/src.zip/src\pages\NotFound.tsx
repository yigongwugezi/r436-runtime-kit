import { useNavigate } from 'react-router-dom';
import { Home } from 'lucide-react';

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center py-20 px-4">
      <p className="text-8xl font-bold text-gray-200 mb-4">404</p>
      <h2 className="text-xl font-semibold text-gray-700 mb-2">ҳ�治����</h2>
      <p className="text-gray-400 mb-8">����ʵ�ҳ������ѱ��Ƴ��򲻴���</p>
      <button
        onClick={() => navigate('/')}
        className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
      >
        <Home className="w-4 h-4" />
        ������ҳ
      </button>
    </div>
  );
}