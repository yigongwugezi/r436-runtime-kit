import client from './client';

export interface KnowledgeSearchResult {
  content: string;
  source: string;
  score: number;
}

export async function searchKnowledge(query: string, k = 3): Promise<KnowledgeSearchResult[]> {
  const { data } = await client.get<{ results: KnowledgeSearchResult[] }>('/knowledge/search', {
    params: { q: query, k },
  });
  return data.results;
}

export async function getKnowledgeOutline(): Promise<string> {
  const { data } = await client.get<{ outline: string }>('/knowledge/outline');
  return data.outline;
}