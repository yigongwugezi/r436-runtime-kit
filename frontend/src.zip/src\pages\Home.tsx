import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, Sparkles, Target, GitFork, BookOpen, ArrowRight } from 'lucide-react';

export default function Home() {
  const [input, setInput] = useState('');
  const navigate = useNavigate();

  const handleStart = () => {
    if (input.trim()) {
      navigate('/chat', { state: { initialMessage: input.trim() } });
    } else {
      navigate('/chat');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-16">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl mb-6">
          <Brain className="w-9 h-9 text-white" />
        </div>
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
          ���Ի�ѧϰ����
        </h1>
        <p className="text-lg text-gray-500 max-w-lg mx-auto">
          ���ǧƪһ�ɵ�ѧϰģʽ���� AI ��������Ϊ����������ѧϰ����
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {[
          { icon: Sparkles, title: 'AI ����', desc: '10 ��������Эͬ' },
          { icon: Target, title: '��׼����', desc: '10 ά��ѧϰ����' },
          { icon: GitFork, title: '��̬·��', desc: '���Ի�ѧϰ�滮' },
          { icon: BookOpen, title: '��ģ̬��Դ', desc: '5 ��ѧϰ����' },
        ].map(({ icon: Icon, title, desc }) => (
          <div key={title} className="bg-white rounded-xl border border-gray-200 p-5 text-center hover:shadow-md transition-shadow">
            <Icon className="w-8 h-8 text-blue-600 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-1">{title}</h3>
            <p className="text-sm text-gray-400">{desc}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-xl">?</span>
          </div>
          <div>
            <p className="font-medium text-gray-900">��ʼ���ѧϰ֮��</p>
            <p className="text-sm text-gray-400 mt-0.5">
              ���������רҵ��ѧϰĿ��ͻ������һ�Ϊ��滮����ѧϰ·��
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleStart()}
            placeholder='���磺"���ǵ�����Ϣ���ѧ����Python����������������AI"'
            className="flex-1 border border-gray-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            onClick={handleStart}
            className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 flex items-center gap-2 transition-colors flex-shrink-0"
          >
            ��ʼ <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}