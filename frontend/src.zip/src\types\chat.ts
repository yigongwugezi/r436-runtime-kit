// ===== ��Ϣ���� =====

import type { StudentProfile } from './profile';
import type { ResourceType } from './resource';

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  stage?: StreamStage;
}

export interface ChatRequest {
  session_id: string;
  message: string;
}

export interface ChatResponse {
  reply: string;
  profile: StudentProfile;
  missing_dimensions: string[];
  follow_up_questions: string[];
}

export type StreamStage =
  | 'profiling'
  | 'diagnosis'
  | 'path_planning'
  | 'generating_lecture'
  | 'generating_quiz'
  | 'generating_mindmap'
  | 'generating_case'
  | 'quality_check'
  | 'complete';

export interface StreamEvent {
  stage: StreamStage;
  message: string;
  progress: number;
  resource_type?: ResourceType;
  chunk?: string;
  resource_ids?: string[];
}

export interface Conversation {
  session_id: string;
  messages: Message[];
  created_at: string;
  updated_at: string;
}