import { useEffect, useRef } from 'react';
import MessageList from './MessageList';
import ChatInput from './ChatInput';
import ProgressIndicator from './ProgressIndicator';
import { useChat } from '../../hooks/useChat';
import { useChatStore } from '../../store/chatStore';

export default function ChatPanel() {
  const { messages, isStreaming, send } = useChat();
  const { currentStage, progress } = useChatStore();
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex flex-col h-full">
      {currentStage && <ProgressIndicator stage={currentStage} progress={progress} />}
      <div className="flex-1 overflow-y-auto">
        <MessageList messages={messages} />
        <div ref={bottomRef} />
      </div>
      <ChatInput onSend={send} disabled={isStreaming} />
    </div>
  );
}