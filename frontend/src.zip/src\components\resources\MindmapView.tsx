import { useEffect, useRef } from 'react';
import { renderMermaid } from '../../utils/mermaid';

interface Props {
  code: string;
}

export default function MindmapView({ code }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current && code) {
      renderMermaid(containerRef.current, code);
    }
  }, [code]);

  return (
    <div className="p-4 overflow-auto">
      <div ref={containerRef} className="min-w-[600px] flex justify-center" />
    </div>
  );
}