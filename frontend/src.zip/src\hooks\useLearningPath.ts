import { useState, useCallback, useEffect } from 'react';
import type { LearningPathData } from '../types/learningPath';

export function useLearningPath(sessionId: string) {
  const [path, setPath] = useState<LearningPathData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPath = useCallback(async () => {
    if (!sessionId) return;
    setLoading(true);
    setError(null);
    try {
      // ·������ͨ����Դ���ɽӿ�һ�𷵻�
      // ���������գ��Ⱥ�˽ӿھ�����Խ�
    } catch (err) {
      setError(err instanceof Error ? err.message : '��ȡѧϰ·��ʧ��');
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    fetchPath();
  }, [fetchPath]);

  const updatePath = useCallback((newPath: LearningPathData) => {
    setPath(newPath);
  }, []);

  return { path, loading, error, updatePath, refresh: fetchPath };
}