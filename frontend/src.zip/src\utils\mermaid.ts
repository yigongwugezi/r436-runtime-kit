import mermaid from 'mermaid';

let initialized = false;

export function initMermaid(): void {
  if (initialized) return;
  mermaid.initialize({
    startOnLoad: true,
    theme: 'default',
    securityLevel: 'loose',
    fontFamily: 'system-ui, sans-serif',
    mindmap: {
      useMaxWidth: true,
      padding: 8,
    },
    flowchart: {
      useMaxWidth: true,
      htmlLabels: true,
      curve: 'basis',
    },
  });
  initialized = true;
}

export async function renderMermaid(element: HTMLElement, code: string): Promise<void> {
  initMermaid();
  const id = `mermaid-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const { svg } = await mermaid.render(id, code);
  element.innerHTML = svg;
}