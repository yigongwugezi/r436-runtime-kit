import { useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { markdownComponents } from '../../utils/markdown';

interface Props {
  chunks: string[];
  isComplete: boolean;
}

export default function StreamText({ chunks, isComplete }: Props) {
  const [displayed, setDisplayed] = useState('');

  useEffect(() => {
    setDisplayed(chunks.join(''));
  }, [chunks]);

  return (
    <div className="prose prose-sm max-w-none text-gray-700">
      <ReactMarkdown components={markdownComponents}>
        {displayed || ''}
      </ReactMarkdown>
      {!isComplete && (
        <span className="inline-block w-2 h-4 bg-blue-500 animate-pulse ml-0.5" />
      )}
    </div>
  );
}