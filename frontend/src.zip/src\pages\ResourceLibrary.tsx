import { useState } from 'react';
import ResourceFilter from '../components/resources/ResourceFilter';
import ResourceCard from '../components/resources/ResourceCard';
import Loading from '../components/common/Loading';
import EmptyState from '../components/common/EmptyState';
import { useResources } from '../hooks/useResources';
import { useChatStore } from '../store/chatStore';
import type { ResourceType } from '../types/resource';

export default function ResourceLibrary() {
  const { sessionId } = useChatStore();
  const { resources, filter, setFilter, loading, error } = useResources(sessionId);
  const [searchInput, setSearchInput] = useState('');

  const handleSearch = (value: string) => {
    setSearchInput(value);
    setFilter({ ...filter, search: value });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-gray-900">? �ҵ�ѧϰ��Դ</h1>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <input
          value={searchInput}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="������Դ..."
          className="flex-1 border border-gray-300 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <ResourceFilter
          selected={filter.type}
          onChange={(type) => setFilter({ ...filter, type: type as ResourceType | 'all' })}
        />
      </div>

      {loading ? (
        <Loading type="card" count={6} />
      ) : error ? (
        <EmptyState title="����ʧ��" description={error} />
      ) : resources.length === 0 ? (
        <EmptyState
          title="����ѧϰ��Դ"
          description="ȥ�Ի�ҳ�濪ʼѧϰ�����ɵ���Դ�����������"
          action={{ label: 'ȥ�Ի�', onClick: () => window.location.href = '/chat' }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resources.map((resource) => (
            <ResourceCard
              key={resource.id}
              resource={resource}
              onClick={() => {/* ��ת�����չ�� */}}
            />
          ))}
        </div>
      )}
    </div>
  );
}