import client from './client';
import type { ResourceItem, ResourceGenerateResponse } from '../types/resource';

export async function generateResources(): Promise<ResourceGenerateResponse> {
  const { data } = await client.post<ResourceGenerateResponse>('/resources/generate');
  return data;
}

export async function generateResourcesStream(
  onStage: (stage: string, message: string, progress: number) => void,
  onResourceChunk: (type: string, chunk: string) => void,
  onComplete: (resourceIds: string[]) => void,
  onError: (error: Error) => void
): Promise<void> {
  try {
    const response = await fetch(`${client.defaults.baseURL}/resources/generate/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) throw new Error('��Դ��������ʧ��');

    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const event = JSON.parse(line.slice(6));
            if (event.stage === 'complete') {
              onComplete(event.resource_ids || []);
            } else if (event.chunk) {
              onResourceChunk(event.resource_type || 'lecture', event.chunk);
            } else {
              onStage(event.stage, event.message, event.progress || 0);
            }
          } catch {
            // ����
          }
        }
      }
    }
  } catch (error) {
    onError(error instanceof Error ? error : new Error('��Դ����ʧ��'));
  }
}

export async function getResources(sessionId: string): Promise<ResourceItem[]> {
  const { data } = await client.get<ResourceItem[]>(`/resources/${sessionId}`);
  return data;
}

export async function getResourceDetail(sessionId: string, resourceId: string): Promise<ResourceItem> {
  const { data } = await client.get<ResourceItem>(`/resources/${sessionId}/${resourceId}`);
  return data;
}