import ReactMarkdown from 'react-markdown';
import { User, Bot, Info } from 'lucide-react';
import type { Message } from '../../types/chat';
import { markdownComponents } from '../../utils/markdown';
import { formatDate } from '../../utils/format';

interface Props {
  message: Message;
}

const roleConfig = {
  user: {
    icon: User,
    bg: 'bg-blue-600 text-white',
    align: 'justify-end',
    bubble: 'bg-blue-600 text-white rounded-2xl rounded-br-md',
  },
  assistant: {
    icon: Bot,
    bg: 'bg-indigo-600 text-white',
    align: 'justify-start',
    bubble: 'bg-white border border-gray-200 rounded-2xl rounded-bl-md shadow-sm',
  },
  system: {
    icon: Info,
    bg: 'bg-gray-400 text-white',
    align: 'justify-center',
    bubble: 'bg-gray-50 border border-gray-200 rounded-xl text-center',
  },
};

export default function MessageBubble({ message }: Props) {
  const config = roleConfig[message.role];
  const Icon = config.icon;

  if (message.role === 'system') {
    return (
      <div className={config.align}>
        <div className={`inline-flex items-center gap-2 px-4 py-2 ${config.bubble} text-sm text-gray-500 max-w-[85%]`}>
          <Icon className="w-4 h-4 flex-shrink-0" />
          <span>{message.content}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex gap-3 ${config.align === 'justify-end' ? 'flex-row-reverse' : ''}`}>
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${config.bg}`}
      >
        <Icon className="w-4 h-4" />
      </div>
      <div className={`max-w-[80%] px-4 py-3 ${config.bubble}`}>
        {message.role === 'assistant' ? (
          <div className="prose prose-sm max-w-none text-gray-700">
            <ReactMarkdown components={markdownComponents}>
              {message.content || '˼����...'}
            </ReactMarkdown>
          </div>
        ) : (
          <p className="text-sm leading-relaxed">{message.content}</p>
        )}
        <span className={`text-xs mt-1 block ${message.role === 'user' ? 'text-blue-200' : 'text-gray-400'}`}>
          {formatDate(new Date(message.timestamp).toISOString())}
        </span>
      </div>
    </div>
  );
}