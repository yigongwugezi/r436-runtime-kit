import { useState } from 'react';
import { Copy, Check, Play } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import ReactMarkdown from 'react-markdown';
import { markdownComponents } from '../../utils/markdown';

interface Props {
  content: string;
}

function extractCodeAndDesc(content: string): { description: string; code: string } {
  const codeMatch = content.match(/```(?:python)?\n?([\s\S]*?)```/);
  const code = codeMatch ? codeMatch[1].trim() : content;
  const description = content.replace(/```[\s\S]*?```/, '').trim();
  return { description, code };
}

export default function CaseView({ content }: Props) {
  const { description, code } = extractCodeAndDesc(content);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-4 space-y-4">
      {description && (
        <div className="prose prose-sm max-w-none text-gray-700">
          <ReactMarkdown components={markdownComponents}>
            {description}
          </ReactMarkdown>
        </div>
      )}

      <div className="relative rounded-xl overflow-hidden border border-gray-200">
        <div className="flex items-center justify-between px-4 py-2 bg-gray-800">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
          </div>
          <div className="flex items-center gap-2">
            <button className="p-1 text-gray-400 hover:text-white">
              <Play className="w-4 h-4" />
            </button>
            <button onClick={handleCopy} className="p-1 text-gray-400 hover:text-white">
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
        <SyntaxHighlighter
          language="python"
          style={oneDark}
          customStyle={{ margin: 0, borderRadius: 0, fontSize: '0.875rem' }}
          showLineNumbers
        >
          {code}
        </SyntaxHighlighter>
      </div>
    </div>
  );
}