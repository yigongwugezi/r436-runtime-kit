import { CheckCircle2, PlayCircle, Circle, Lock } from 'lucide-react';
import type { PathStage } from '../../types/learningPath';
import { STAGE_STATUS_COLORS } from '../../utils/constants';

interface Props {
  stage: PathStage;
  onClick?: () => void;
}

const statusIcons = {
  completed: CheckCircle2,
  in_progress: PlayCircle,
  pending: Circle,
  locked: Lock,
};

const statusLabels = {
  completed: '�����',
  in_progress: 'ѧϰ��',
  pending: '��ѧϰ',
  locked: 'δ����',
};

export default function PathNode({ stage, onClick }: Props) {
  const Icon = statusIcons[stage.status];

  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all hover:shadow-md ${
        STAGE_STATUS_COLORS[stage.status]
      }`}
    >
      <Icon className="w-6 h-6 flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-xs font-medium text-gray-400">�׶� {stage.stage}</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100">{statusLabels[stage.status]}</span>
        </div>
        <h4 className="font-medium text-gray-900">{stage.topic}</h4>
        <p className="text-xs text-gray-400 mt-0.5">{stage.description}</p>
        <div className="flex items-center gap-3 mt-1.5">
          <span className="text-xs text-gray-400">? {stage.duration}</span>
          <span className="text-xs text-gray-400">? {stage.resources.length} ����Դ</span>
        </div>
      </div>
    </div>
  );
}