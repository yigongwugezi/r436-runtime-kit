import { Loader2, UserCheck, Search, GitFork, FileText, ShieldCheck } from 'lucide-react';
import type { StreamStage } from '../../types/chat';

interface Props {
  stage: StreamStage;
  progress: number;
}

const stageConfig: Record<string, { icon: React.FC<{ className?: string }>; label: string }> = {
  profiling: { icon: UserCheck, label: '����ѧϰ����' },
  diagnosis: { icon: Search, label: '���֪ʶ�̰�' },
  path_planning: { icon: GitFork, label: '�滮ѧϰ·��' },
  generating_lecture: { icon: FileText, label: '���ɽ���' },
  generating_quiz: { icon: FileText, label: '������ϰ��' },
  generating_mindmap: { icon: GitFork, label: '����˼ά��ͼ' },
  generating_case: { icon: FileText, label: '����ʵ�ٰ���' },
  quality_check: { icon: ShieldCheck, label: '�������' },
};

export default function ProgressIndicator({ stage, progress }: Props) {
  const config = stageConfig[stage];

  if (!config) return null;

  const Icon = config.icon;

  return (
    <div className="bg-blue-50 border-b border-blue-100 px-4 py-2.5">
      <div className="flex items-center gap-2.5">
        {progress < 1 ? (
          <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
        ) : (
          <Icon className="w-4 h-4 text-blue-600" />
        )}
        <span className="text-sm text-blue-700 font-medium">{config.label}</span>
        <span className="text-xs text-blue-400 ml-auto">{Math.round(progress * 100)}%</span>
      </div>
      <div className="mt-1.5 h-1 bg-blue-200 rounded-full overflow-hidden">
        <div
          className="h-full bg-blue-600 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${progress * 100}%` }}
        />
      </div>
    </div>
  );
}