import type { ProfileHistoryItem } from '../../types/profile';
import { formatDate } from '../../utils/format';

interface Props {
  history: ProfileHistoryItem[];
}

export default function ProfileHistory({ history }: Props) {
  if (history.length === 0) {
    return <p className="text-sm text-gray-400 text-center py-8">���޸��¼�¼</p>;
  }

  return (
    <div className="space-y-3">
      {history.map((item, index) => (
        <div key={index} className="flex gap-3">
          <div className="flex flex-col items-center">
            <div className="w-2 h-2 rounded-full bg-blue-500 mt-2" />
            {index < history.length - 1 && <div className="w-px flex-1 bg-gray-200 mt-1" />}
          </div>
          <div className="flex-1 pb-4">
            <p className="text-sm text-gray-700">
              ������ <span className="font-medium">{item.dimension}</span>
            </p>
            <p className="text-xs text-gray-400 mt-0.5">{formatDate(item.timestamp)}</p>
          </div>
        </div>
      ))}
    </div>
  );
}