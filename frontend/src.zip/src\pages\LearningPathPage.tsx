import LearningPath from '../components/learning/LearningPath';
import PathNode from '../components/learning/PathNode';
import ProgressBar from '../components/learning/ProgressBar';
import Loading from '../components/common/Loading';
import EmptyState from '../components/common/EmptyState';
import { useLearningPath } from '../hooks/useLearningPath';
import { useChatStore } from '../store/chatStore';

export default function LearningPathPage() {
  const { sessionId } = useChatStore();
  const { path, loading, error } = useLearningPath(sessionId);

  if (loading) {
    return <Loading type="skeleton" count={4} className="max-w-3xl mx-auto px-4 py-8" />;
  }

  if (error) {
    return <EmptyState title="����ʧ��" description={error} />;
  }

  if (!path) {
    return (
      <EmptyState
        title="����ѧϰ·��"
        description="���ѧϰ��Ϻ�ϵͳ��Ϊ��滮���Ի�ѧϰ·��"
        action={{ label: 'ȥ�Ի�', onClick: () => window.location.href = '/chat' }}
      />
    );
  }

  const completed = path.stages.filter((s) => s.status === 'completed').length;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-gray-900">?? ѧϰ·��</h1>
        <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
          ���¹滮
        </button>
      </div>

      <div className="mb-6">
        <ProgressBar completed={completed} total={path.stages.length} />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6 overflow-auto">
        <LearningPath path={path} />
      </div>

      <div className="space-y-3">
        {path.stages.map((stage) => (
          <PathNode
            key={stage.stage}
            stage={stage}
            onClick={() => {/* ��ת��Ӧ��Դ */}}
          />
        ))}
      </div>
    </div>
  );
}