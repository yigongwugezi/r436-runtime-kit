import type { ResourceType } from '../../types/resource';
import { RESOURCE_TYPE_LABELS } from '../../utils/constants';

interface Props {
  selected: ResourceType | 'all';
  onChange: (type: ResourceType | 'all') => void;
}

const types: Array<ResourceType | 'all'> = ['all', 'lecture', 'mindmap', 'quiz', 'reading', 'case', 'video'];

export default function ResourceFilter({ selected, onChange }: Props) {
  return (
    <div className="flex gap-2 flex-wrap">
      {types.map((type: ResourceType | 'all') => (
        <button
          key={type}
          onClick={() => onChange(type)}
          className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
            selected === type
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          {type === 'all' ? 'ȫ��' : RESOURCE_TYPE_LABELS[type]}
        </button>
      ))}
    </div>
  );
}