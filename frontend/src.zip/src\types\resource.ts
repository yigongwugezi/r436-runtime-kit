// ===== ��Դ���� =====

import type { LearningPathData } from './learningPath';

export type ResourceType = 'lecture' | 'mindmap' | 'quiz' | 'reading' | 'case' | 'video';

export type ResourceStatus = 'generating' | 'completed' | 'failed';

export interface ResourceItem {
  id: string;
  session_id: string;
  type: ResourceType;
  title: string;
  topic: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
  content: string;
  status: ResourceStatus;
  created_at: string;
}

export interface ResourceGenerateRequest {
  session_id: string;
}

export interface ResourceGenerateResponse {
  learning_path: LearningPathData;
  resources: ResourceItem[];
}

export interface ResourceFilter {
  type: ResourceType | 'all';
  difficulty: string;
  search: string;
}

export interface QuizQuestion {
  type: 'choice' | 'true_false' | 'short_answer';
  question: string;
  options?: string[];
  answer: string;
  solution: string;
  difficulty_score: number;
}

export interface QuizResult {
  question_index: number;
  user_answer: string;
  correct: boolean;
  error_type?: 'concept' | 'calculation' | 'misread' | 'method' | 'forgotten';
}