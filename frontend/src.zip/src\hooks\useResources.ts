import { useState, useCallback, useEffect } from 'react';
import type { ResourceItem, ResourceFilter } from '../types/resource';
import { getResources } from '../api/resources';

export function useResources(sessionId: string) {
  const [resources, setResources] = useState<ResourceItem[]>([]);
  const [filter, setFilter] = useState<ResourceFilter>({ type: 'all', difficulty: '', search: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchResources = useCallback(async () => {
    if (!sessionId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await getResources(sessionId);
      setResources(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : '��ȡ��Դʧ��');
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    fetchResources();
  }, [fetchResources]);

  const filteredResources = resources.filter((r) => {
    if (filter.type !== 'all' && r.type !== filter.type) return false;
    if (filter.difficulty && r.difficulty !== filter.difficulty) return false;
    if (filter.search && !r.title.includes(filter.search) && !r.topic.includes(filter.search)) return false;
    return true;
  });

  return {
    resources: filteredResources,
    allResources: resources,
    filter,
    setFilter,
    loading,
    error,
    refresh: fetchResources,
  };
}