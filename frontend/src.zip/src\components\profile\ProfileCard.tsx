import type { StudentProfile } from '../../types/profile';
import ProfileDimension from './ProfileDimension';
import EmptyState from '../common/EmptyState';

interface Props {
  profile: StudentProfile | null;
  onEdit?: (dimension: string, value: unknown) => void;
}

export default function ProfileCard({ profile, onEdit }: Props) {
  if (!profile) {
    return (
      <EmptyState
        title="����ѧϰ����"
        description="��ʼ�Ի���ϵͳ���Զ��������ѧϰ����"
      />
    );
  }

  const { dimensions } = profile;

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h3 className="text-base font-semibold text-gray-900 mb-4">? ѧϰ����</h3>
      <div className="grid grid-cols-2 gap-3">
        {Object.entries(dimensions).map(([key, dim]) => (
          <ProfileDimension
            key={key}
            name={key}
            dimension={dim}
            onEdit={(value) => onEdit?.(key, value)}
          />
        ))}
      </div>
    </div>
  );
}