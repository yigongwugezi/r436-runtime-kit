export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return '�ո�';
  if (minutes < 60) return `${minutes}����ǰ`;
  if (hours < 24) return `${hours}Сʱǰ`;
  if (days < 7) return `${days}��ǰ`;
  return date.toLocaleDateString('zh-CN');
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes}����`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}Сʱ${mins}����` : `${hours}Сʱ`;
}

export function formatPercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
}