import { useEffect, useCallback } from 'react';
import { useProfileStore } from '../store/profileStore';
import { getProfile, getLearningStats, updateProfile } from '../api/profile';

export function useProfile(sessionId: string) {
  const { profile, stats, isUpdating, setProfile, setStats, setUpdating, setError } = useProfileStore();

  const fetchProfile = useCallback(async () => {
    if (!sessionId) return;
    try {
      const [profileData, statsData] = await Promise.all([
        getProfile(sessionId),
        getLearningStats(sessionId),
      ]);
      setProfile(profileData);
      setStats(statsData);
    } catch (err) {
      setError(err instanceof Error ? err.message : '��ȡ����ʧ��');
    }
  }, [sessionId, setProfile, setStats, setError]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  const update = useCallback(
    async (dimension: string, value: unknown) => {
      setUpdating(true);
      try {
        const updated = await updateProfile(dimension, value);
        setProfile(updated);
      } catch (err) {
        setError(err instanceof Error ? err.message : '���»���ʧ��');
      } finally {
        setUpdating(false);
      }
    },
    [setUpdating, setProfile, setError]
  );

  return { profile, stats, isUpdating, update, refresh: fetchProfile };
}