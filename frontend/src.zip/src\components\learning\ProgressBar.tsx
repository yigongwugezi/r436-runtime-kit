interface Props {
  completed: number;
  total: number;
  showLabel?: boolean;
  className?: string;
}

export default function ProgressBar({ completed, total, showLabel = true, className = '' }: Props) {
  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className={className}>
      {showLabel && (
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-gray-500">ѧϰ����</span>
          <span className="text-xs font-medium text-gray-700">
            {completed}/{total} ({percent}%)
          </span>
        </div>
      )}
      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-700 ease-out"
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}