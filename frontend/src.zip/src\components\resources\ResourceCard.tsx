import { FileText, GitFork, Pencil, BookOpen, Code, Video, ChevronRight } from 'lucide-react';
import type { ResourceItem, ResourceType } from '../../types/resource';
import { DIFFICULTY_COLORS } from '../../utils/constants';
import { formatDate } from '../../utils/format';

interface Props {
  resource: ResourceItem;
  onClick?: () => void;
}

const typeConfig: Record<ResourceType, { icon: React.FC<{ className?: string }>; label: string; color: string }> = {
  lecture: { icon: FileText, label: '����', color: 'text-blue-600 bg-blue-50' },
  mindmap: { icon: GitFork, label: '˼ά��ͼ', color: 'text-purple-600 bg-purple-50' },
  quiz: { icon: Pencil, label: '��ϰ��', color: 'text-orange-600 bg-orange-50' },
  reading: { icon: BookOpen, label: '��չ�Ķ�', color: 'text-green-600 bg-green-50' },
  case: { icon: Code, label: 'ʵ�ٰ���', color: 'text-indigo-600 bg-indigo-50' },
  video: { icon: Video, label: '��ѧ��Ƶ', color: 'text-pink-600 bg-pink-50' },
};

export default function ResourceCard({ resource, onClick }: Props) {
  const config = typeConfig[resource.type] || typeConfig.lecture;
  const Icon = config.icon;

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl border border-gray-200 p-4 cursor-pointer hover:shadow-md hover:border-blue-200 transition-all group"
    >
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${config.color}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-medium text-gray-500 px-2 py-0.5 bg-gray-100 rounded-full">
              {config.label}
            </span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${DIFFICULTY_COLORS[resource.difficulty]}`}>
              {resource.difficulty === 'beginner' ? '����' : resource.difficulty === 'intermediate' ? '����' : '�߼�'}
            </span>
          </div>
          <h4 className="font-medium text-gray-900 truncate">{resource.title}</h4>
          <p className="text-xs text-gray-400 mt-1">{resource.topic}</p>
          <p className="text-xs text-gray-300 mt-1">{formatDate(resource.created_at)}</p>
        </div>
        <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-blue-500 flex-shrink-0 mt-2" />
      </div>
    </div>
  );
}