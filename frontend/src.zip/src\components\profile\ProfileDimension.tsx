import type { DimensionValue } from '../../types/profile';
import { formatPercent } from '../../utils/format';

interface Props {
  name: string;
  dimension: DimensionValue;
  onEdit?: (value: unknown) => void;
}

const dimensionLabels: Record<string, string> = {
  major: 'רҵ����',
  grade: '�꼶',
  knowledge_base: '֪ʶ����',
  learning_goal: 'ѧϰĿ��',
  cognitive_style: '��֪���',
  weakness_patterns: '�״���',
  programming_ability: '�������',
  learning_pace: 'ѧϰ����',
  interest_direction: '��Ȥ����',
  available_time: '����ʱ��',
};

const sourceColors: Record<string, string> = {
  user_input: 'bg-green-100 text-green-700',
  inferred: 'bg-blue-100 text-blue-700',
  diagnosis: 'bg-purple-100 text-purple-700',
};

export default function ProfileDimension({ name, dimension, onEdit }: Props) {
  const label = dimensionLabels[name] || name;
  const displayValue = Array.isArray(dimension.value)
    ? dimension.value.join(', ')
    : typeof dimension.value === 'object' && dimension.value !== null
      ? Object.entries(dimension.value as Record<string, number>)
          .map(([k, v]) => `${k}: ${formatPercent(v)}`)
          .join(', ')
      : String(dimension.value);

  return (
    <div className="bg-gray-50 rounded-lg p-3 group">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-gray-500">{label}</span>
        <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${sourceColors[dimension.source] || 'bg-gray-100'}`}>
          {dimension.source === 'user_input' ? '�û�' : dimension.source === 'inferred' ? '�ƶ�' : '���'}
        </span>
      </div>
      <p className="text-sm font-medium text-gray-800 truncate">{displayValue || 'δ֪'}</p>
      <div className="flex items-center gap-2 mt-1.5">
        <div className="flex-1 h-1 bg-gray-200 rounded-full">
          <div
            className="h-full bg-blue-500 rounded-full transition-all"
            style={{ width: `${dimension.confidence * 100}%` }}
          />
        </div>
        <span className="text-[10px] text-gray-400">{formatPercent(dimension.confidence)}</span>
      </div>
      {onEdit && (
        <button
          onClick={() => onEdit(dimension.value)}
          className="mt-1 text-[10px] text-gray-400 hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          �༭
        </button>
      )}
    </div>
  );
}