import ProfileCard from '../components/profile/ProfileCard';
import DimensionRadar from '../components/profile/DimensionRadar';
import ProfileHistory from '../components/profile/ProfileHistory';
import ProgressBar from '../components/learning/ProgressBar';
import Loading from '../components/common/Loading';
import EmptyState from '../components/common/EmptyState';
import { useProfile } from '../hooks/useProfile';
import { useChatStore } from '../store/chatStore';
import { BookOpen, FileText, CheckCircle2, Calendar } from 'lucide-react';

export default function ProfilePage() {
  const { sessionId } = useChatStore();
  const { profile, stats, isUpdating, update } = useProfile(sessionId);

  if (!profile) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8">
        <EmptyState
          title="����ѧϰ����"
          description="ȥ�Ի�ҳ���AI��һ�ģ�ϵͳ���Զ��������ѧϰ����"
          action={{ label: 'ȥ�Ի�', onClick: () => window.location.href = '/chat' }}
        />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <h1 className="text-xl font-bold text-gray-900">? �ҵ�ѧϰ����</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-sm font-semibold text-gray-500 mb-4">�����״�ͼ</h3>
          <DimensionRadar profile={profile} />
        </div>

        <ProfileCard profile={profile} onEdit={update} />
      </div>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: BookOpen, label: '��ѧ֪ʶ��', value: `${stats.mastered_count}/${stats.total_knowledge_points}` },
            { icon: FileText, label: '������Դ', value: `${stats.total_resources} ��` },
            { icon: CheckCircle2, label: '��ϰ��ȷ��', value: `${Math.round(stats.quiz_accuracy * 100)}%` },
            { icon: Calendar, label: 'ѧϰ����', value: `${stats.study_days} ��` },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label} className="bg-white rounded-xl border border-gray-200 p-4 text-center">
              <Icon className="w-6 h-6 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-900">{value}</p>
              <p className="text-xs text-gray-400 mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-sm font-semibold text-gray-500 mb-4">? ���������ʷ</h3>
        <ProfileHistory history={[]} />
      </div>
    </div>
  );
}