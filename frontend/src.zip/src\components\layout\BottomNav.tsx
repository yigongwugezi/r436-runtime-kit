import { useNavigate, useLocation } from 'react-router-dom';
import { Home, MessageSquare, Library, GitFork, User } from 'lucide-react';

const tabs = [
  { path: '/', label: '��ҳ', icon: Home },
  { path: '/chat', label: '�Ի�', icon: MessageSquare },
  { path: '/resources', label: '��Դ��', icon: Library },
  { path: '/path', label: 'ѧϰ·��', icon: GitFork },
  { path: '/profile', label: '����', icon: User },
];

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <nav className="bg-white border-t border-gray-200 sticky bottom-0 z-40 md:hidden">
      <div className="flex items-center justify-around h-16">
        {tabs.map(({ path, label, icon: Icon }) => {
          const isActive = location.pathname === path;
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg transition-colors min-w-[60px] ${
                isActive
                  ? 'text-blue-600'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}