declare module 'react-syntax-highlighter';
declare module 'react-syntax-highlighter/dist/esm/styles/prism';
declare module 'react-syntax-highlighter/dist/cjs/index.js';
declare module 'react-syntax-highlighter/dist/esm/styles/prism/index.js';