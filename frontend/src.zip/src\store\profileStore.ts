import { create } from 'zustand';
import type { StudentProfile, LearningStats } from '../types/profile';

interface ProfileState {
  profile: StudentProfile | null;
  stats: LearningStats | null;
  isUpdating: boolean;
  error: string | null;

  setProfile: (profile: StudentProfile) => void;
  setStats: (stats: LearningStats) => void;
  setUpdating: (updating: boolean) => void;
  setError: (error: string | null) => void;
  updateDimension: (dimension: string, value: unknown) => void;
}

export const useProfileStore = create<ProfileState>((set, get) => ({
  profile: null,
  stats: null,
  isUpdating: false,
  error: null,

  setProfile: (profile) => {
    if (profile.session_id) {
      localStorage.setItem('eduagent_session_id', profile.session_id);
    }
    set({ profile });
  },

  setStats: (stats) => set({ stats }),
  setUpdating: (updating) => set({ isUpdating: updating }),
  setError: (error) => set({ error }),

  updateDimension: (dimension, value) => {
    const { profile } = get();
    if (!profile) return;
    set({
      profile: {
        ...profile,
        dimensions: {
          ...profile.dimensions,
          [dimension]: {
            ...profile.dimensions[dimension as keyof typeof profile.dimensions],
            value,
            source: 'user_input',
            confidence: 1.0,
            last_updated: new Date().toISOString(),
          },
        },
      },
    });
  },
}));